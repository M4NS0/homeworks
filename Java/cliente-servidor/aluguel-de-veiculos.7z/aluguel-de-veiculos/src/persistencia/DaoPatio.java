package persistencia;

import modelos.Patio;

import java.util.List;

public class DaoPatio {
    public List<Patio> obterTudo() {
        List<Patio> patios = null;
        return patios;
    }

    public Patio buscarPatio(int codigoPatio) {
        Patio patio = null;
        return patio;
    }
}
