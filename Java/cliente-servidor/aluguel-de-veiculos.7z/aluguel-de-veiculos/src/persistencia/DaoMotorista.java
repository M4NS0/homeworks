package persistencia;

import modelos.Motorista;

import java.util.List;

public class DaoMotorista {
    public List<Motorista> obterTudo() {
        List<Motorista> motoristas = null;
        return motoristas;
    }

    public Motorista buscarMotorista(int codigoMotorista) {
        Motorista motorista = null;
        return motorista;
    }
}
