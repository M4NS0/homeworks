package persistencia;

import modelos.Pedido;

import java.util.List;

public class DaoPedido {

    public List<Pedido> obterTudo() {
        List<Pedido> pedidos = null;
        return pedidos;
    }

    public void inserir(Pedido pedido) {
        // TODO implement here
    }
}
