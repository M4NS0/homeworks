package persistencia;

import modelos.Cliente;

import java.util.List;

public class DaoCliente {
    public List<Cliente> obterTudo() {
        List<Cliente> clientes = null;
        return clientes;
    }

    public void inserir(Cliente cliente) {

    }

    public Cliente buscarCliente(int codigoCliente) {
        Cliente cliente = null;
        return cliente;
    }
}
