package persistencia;

import modelos.Carro;

import java.util.List;

public class DaoCarro {
    public List<Carro> obterTudo() {
        List<Carro> carros = null;
        return carros;
    }

    public Carro buscarCarro(int codigoCarro) {
        Carro carro = null;
        return carro;
    }
}
