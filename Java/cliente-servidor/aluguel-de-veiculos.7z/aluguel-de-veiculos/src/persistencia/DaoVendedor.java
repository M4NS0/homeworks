package persistencia;

import modelos.Vendedor;

import java.util.List;

public class DaoVendedor {
    public List<Vendedor> obterTudo() {
        List<Vendedor> vendedores = null;
        return vendedores;
    }

    public Vendedor buscarVendedor(int codigoVendedor) {
        Vendedor vendedor = null;
        return vendedor;

    }
}
