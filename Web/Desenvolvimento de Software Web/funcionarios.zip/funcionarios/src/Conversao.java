

public class Conversao {
	String str = "\n" + 
			"	<style>\n" + 
			"		body {\n" + 
			"		\n" + 
			"			background: rgb(128, 56, 163);\n" + 
			"			background: radial-gradient(circle, rgb(189, 255, 136) 0%,\n" + 
			"					rgb(45, 160, 135) 100%);\n" + 
			"			filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#c9de96',\n" + 
			"					endColorstr='#398235', GradientType=0);\n" + 
			"			/* IE6-9 */\n" + 
			"		}\n" + 
			"\n" + 
			"		.mdl-layout {\n" + 
			"			align-items: center;\n" + 
			"			justify-content: center;\n" + 
			"		}\n" + 
			"\n" + 
			"		.mdl-layout__content {\n" + 
			"			padding: 24px;\n" + 
			"			flex: none;\n" + 
			"		}\n" + 
			"\n" + 
			"		div.card {\n" + 
			"			margin-left: 35%;\n" + 
			"			margin-right: 35%;\n" + 
			"			margin-top: 30px;\n" + 
			"			margin-bottom: 5%;\n" + 
			"			box-shadow: 0 5px 10px rgba(0, 0, 0, 0.6);\n" + 
			"		}\n" + 
			"\n" + 
			"		div.col-md-12.text-center {\n" + 
			"			display: inline-block;\n" + 
			"			font-weight: bold;\n" + 
			"		}\n" + 
			"\n" + 
			"		a.btn {\n" + 
			"			width: 95px;\n" + 
			"			height: auto;\n" + 
			"			margin: 3%;\n" + 
			"			margin-top: 10%;\n" + 
			"			border: solid;\n" + 
			"			border-width: 1px;\n" + 
			"			border-color: black;\n" + 
			"			box-shadow: 0 5px 10px rgba(0, 0, 0, 0.8);\n" + 
			"		}\n" + 
			"\n" + 
			"		a.btn.btn-dark {\n" + 
			"			width: 95px;\n" + 
			"			height: auto;\n" + 
			"			color: whitesmoke;\n" + 
			"		}\n" + 
			"\n" + 
			"		a.btn-dark:hover {\n" + 
			"			color: whitesmoke;\n" + 
			"			border: solid;\n" + 
			"			border-width: 1px;\n" + 
			"			border-color: rgba(0, 0, 0, 0.624);\n" + 
			"		}\n" + 
			"\n" + 
			"		h2.mdl-card__title-text {\n" + 
			"			color: whitesmoke;\n" + 
			"			font-family: monospace;\n" + 
			"			background-color: #424242;\n" + 
			"			font-size: larger;\n" + 
			"			font-weight: normal;\n" + 
			"		}\n" + 
			"\n" + 
			"		div.mdl-card__title.mdl-color--grey-800.mdl-color-text--white {\n" + 
			"			box-shadow: 0 2px 2px rgba(0, 0, 0, 0.5);\n" + 
			"		}\n" + 
			"\n" + 
			"		div.mdl-textfield.mdl-js-textfield.is-upgraded {\n" + 
			"			color: #bfbfbf;\n" + 
			"		}\n" + 
			"\n" + 
			"		form div button.btn-lg {\n" + 
			"			margin-left: 20%;\n" + 
			"			margin-top: 60px;\n" + 
			"			box-shadow: 0 5px 10px rgba(0, 0, 0, 0.6);\n" + 
			"		}\n" + 
			"\n" + 
			"		div.mdl-card__supporting-text form div.row {\n" + 
			"			margin-top: 35px;\n" + 
			"		}\n" + 
			"\n" + 
			"		form div.row div.col-sm-6 label {\n" + 
			"			color: #bfbfbf;\n" + 
			"			margin-top: 5px;\n" + 
			"		}\n" + 
			"\n" + 
			"		div.col-sm-6 select#departamento,\n" + 
			"		div.col-sm-6 select#cargo {\n" + 
			"			width: 120px;\n" + 
			"		}\n" + 
			"	</style>\n" + 
			"</head>\n" + 
			"\n" + 
			"<body>\n" + 
			"	<div class=\"mdl-layout mdl-js-layout\">\n" + 
			"		<div class=\"mdl-layout mdl-js-layout\">\n" + 
			"			<main class=\"mdl-layout__content\">\n" + 
			"				<div class=\"mdl-card mdl-shadow--8dp\">\n" + 
			"					<div class=\"mdl-card__title mdl-color--grey-800 mdl-color-text--white\">\n" + 
			"						<h2 class=\"mdl-card__title-text\">Cadastro</h2>\n" + 
			"					</div>\n" + 
			"					<div class=\"mdl-card__supporting-text\">\n" + 
			"						<form method=\"post\" name=\"dados\" action=\"http://localhost:8282/CadastroFuncionarios/AdicionaFuncionario\">\n" + 
			"							<div class=\"mdl-textfield mdl-js-textfield\">\n" + 
			"								<input class=\"mdl-textfield__input\" type=\"text\" name=\"nome\" required /> <label\n" + 
			"									class=\"mdl-textfield__label\" for=\"text\">Nome</label>\n" + 
			"							</div>\n" + 
			"							<div class=\"mdl-textfield mdl-js-textfield\">\n" + 
			"								<input class=\"mdl-textfield__input\" type=\"text\" name=\"cpf\" maxlength=\"11\"\n" + 
			"									onblur=\"return validaCPF(this.value)\" required /> <label\n" + 
			"									class=\"mdl-textfield__label\" for=\"text\">CPF</label>\n" + 
			"							</div>\n" + 
			"							<div class=\"mdl-textfield mdl-js-textfield\">\n" + 
			"								<input class=\"mdl-textfield__input\" type=\"text\" name=\"nascimento\" maxlength=\"10\"\n" + 
			"									onblur=\"return validaData(this.value)\" required /> <label\n" + 
			"									class=\"mdl-textfield__label\" for=\"date\">Nascimento</label>\n" + 
			"							</div>\n" + 
			"							<div class=\"mdl-textfield mdl-js-textfield\">\n" + 
			"								<input class=\"mdl-textfield__input\" type=\"text\" name=\"salario\"\n" + 
			"									onblur=\"return validaDecimal(this)\" required /> <label class=\"mdl-textfield__label\"\n" + 
			"									for=\"text\" >Salário\n" + 
			"									Base</label>\n" + 
			"							</div>\n" + 
			"							<div class=\"row\">\n" + 
			"								<div class=\"col-sm-6\">\n" + 
			"									<label for=\"departamento\">Departamento: </label>\n" + 
			"								</div>\n" + 
			"								<div class=\"col-sm-6\">\n" + 
			"									<select id=\"departamento\" name=\"departamento\">\n" + 
			"										<option value=\"\">Selecione</option>\n" + 
			"										<option value=\"Diretoria\">Diretoria</option>\n" + 
			"										<option value=\"Administrativo\">Administrativo</option>\n" + 
			"										<option value=\"TI\">Tecnologia da Informação</option>\n" + 
			"										<option value=\"Financeiro\">Financeiro</option>\n" + 
			"									</select>\n" + 
			"								</div>\n" + 
			"							</div>\n" + 
			"							<div class=\"row\">\n" + 
			"								<div class=\"col-sm-6\">\n" + 
			"									<label for=\"cargo\">Cargo: </label>\n" + 
			"								</div>\n" + 
			"								<div class=\"col-sm-6\">\n" + 
			"									<select id=\"cargo\" name=\"cargo\">\n" + 
			"										<option value=\"\">Selecione</option>\n" + 
			"										<option value=\"Diretor\">Diretor</option>\n" + 
			"										<option value=\"Assistente\">Assistente</option>\n" + 
			"										<option value=\"Auxiliar\">Auxiliar</option>\n" + 
			"										<option value=\"Estagiario\">Estagiário</option>\n" + 
			"									</select>\n" + 
			"								</div>\n" + 
			"							</div>\n" + 
			"							<div class=\"container-fluid\">\n" + 
			"								<div class=\"row\">\n" + 
			"									<div class=\"col-sm-6\">\n" + 
			"										<button type=\"submit\" value=\"salvar\" name=\"salvar\"\n" + 
			"											class=\"btn btn-success btn-lg\">Salvar</button>\n" + 
			"									</div>\n" + 
			"									<div class=\"col-sm-6\">\n" + 
			"										<button type=\"reset\" value=\"reset\" name=\"limpar\"\n" + 
			"											class=\"btn btn-danger btn-lg\">Limpar</button>\n" + 
			"									</div>\n" + 
			"								</div>\n" + 
			"							</div>\n" + 
			"						</form>\n" + 
			"					</div>\n" + 
			"				</div>\n" + 
			"			</main>\n" + 
			"		</div>\n" + 
			"	</div>\n" + 
			"	<script>\n" + 
			"\n" + 
			"		function validaCPF(dados) {\n" + 
			"			var i;\n" + 
			"			s = dados;\n" + 
			"			var dados = s.substr(0, 9);\n" + 
			"			var dv = s.substr(9, 2);\n" + 
			"			var d1 = 0;\n" + 
			"			var v = false;\n" + 
			"\n" + 
			"			for (i = 0; i < 9; i++) {\n" + 
			"				d1 += dados.charAt(i) * (10 - i);\n" + 
			"			}\n" + 
			"			if (d1 == 0) {\n" + 
			"				alert(\"Atenção! O Cpf deve ser Digitado\");\n" + 
			"				v = true;\n" + 
			"				return false;\n" + 
			"			}\n" + 
			"			d1 = 11 - (d1 % 11);\n" + 
			"			if (d1 > 9) d1 = 0;\n" + 
			"			if (dv.charAt(0) != d1) {\n" + 
			"				alert(\"CPF Inválido, não use pontos ou traços, use apenas os 11 números\");\n" + 
			"				v = true;\n" + 
			"				return false;\n" + 
			"			}\n" + 
			"\n" + 
			"			d1 *= 2;\n" + 
			"			for (i = 0; i < 9; i++) {\n" + 
			"				d1 += c.charAt(i) * (11 - i);\n" + 
			"			}\n" + 
			"			d1 = 11 - (d1 % 11);\n" + 
			"			if (d1 > 9) d1 = 0;\n" + 
			"			if (dv.charAt(1) != d1) {\n" + 
			"				alert(\"CPF Inválido, não use pontos ou traços, use apenas os 11 números\");\n" + 
			"				v = true;\n" + 
			"				return false;\n" + 
			"			}\n" + 
			"		}\n" + 
			"\n" + 
			"		function validaData(data) {\n" + 
			"			var date = data;\n" + 
			"			var ardt = new Array;\n" + 
			"			var ExpReg = new RegExp(\"(0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[012])/[12][0-9]{3}\");\n" + 
			"			ardt = date.split(\"/\");\n" + 
			"			erro = false;\n" + 
			"			if (date.search(ExpReg) == -1) {\n" + 
			"				erro = true;\n" + 
			"			} else if (((ardt[1] == 4) || (ardt[1] == 6) || (ardt[1] == 9) || (ardt[1] == 11)) && (ardt[0] > 30))\n" + 
			"				erro = true;\n" + 
			"			else if (ardt[1] == 2) {\n" + 
			"				if ((ardt[0] > 28) && ((ardt[2] % 4) != 0))\n" + 
			"					erro = true;\n" + 
			"				if ((ardt[0] > 29) && ((ardt[2] % 4) == 0))\n" + 
			"					erro = true;\n" + 
			"			}\n" + 
			"			if (erro) {\n" + 
			"				alert(data + \"A data de nascimento precisa ser inserida, utilize o formato MM/DD/AAAA\");\n" + 
			"				return false;\n" + 
			"			}\n" + 
			"			return true;\n" + 
			"		}\n" + 
			"\n" + 
			"		function validaDecimal(data) {\n" + 
			"			var decimal = /^[-+]?[0-9]+\\.[0-9]+$/;\n" + 
			"			if (data.value.match(decimal)) {\n" + 
			"				return true;\n" + 
			"			} else {\n" + 
			"				alert('O salário base não pode estar vazio e deve conter números com 2 casas decimais separadas por ponto')\n" + 
			"				return false;\n" + 
			"			}\n" + 
			"		}  ";
}
