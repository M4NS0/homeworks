package br.com.crudelis.junit;

import static org.junit.Assert.*;
import org.junit.Test;

import br.com.crudelis.model.ModificaStatus;

public class Teste {
	ModificaStatus teste = new ModificaStatus();

	@Test
	public void testeNotas100e100() {
		assertEquals("Aprovado por Nota e Presenças", teste.CalculaNota(100.0d, 100.0d, 80, 80));
	}

	@Test
	public void testeNotas90e100() {
		assertEquals("Aprovado por Nota e Presenças", teste.CalculaNota(90.0d, 100.0d, 80, 80));
	}

	@Test
	public void testeNotas80e100() {
		assertEquals("Aprovado por Nota e Presenças", teste.CalculaNota(80.0d, 100.0d, 80, 80));
	}

	@Test
	public void testeNotas70e100() {
		assertEquals("Aprovado por Nota e Presenças", teste.CalculaNota(70.0d, 100.0d, 80, 80));
	}

	@Test
	public void testeNotas60e100() {
		assertEquals("Aprovado por Nota e Presenças", teste.CalculaNota(60.0d, 100.0d, 80, 80));
	}

	@Test
	public void testeNotas50e100() {
		assertEquals("Aprovado por Nota e Presenças", teste.CalculaNota(50.0d, 100.0d, 80, 80));
	}

	@Test
	public void testeNotas40e100() {
		assertEquals("Aprovado por Nota e Presenças", teste.CalculaNota(40.0d, 100.0d, 80, 80));
	}

	@Test
	public void testeNotas30e100() {
		assertEquals("Aprovado por Nota e Presenças", teste.CalculaNota(30.0d, 100.0d, 80, 80));
	}

	@Test
	public void testeNotas20e100() {
		assertEquals("Aprovado por Nota e Presenças", teste.CalculaNota(20.0d, 100.0d, 80, 80));
	}

	@Test
	public void testeNotas10e100() {
		assertEquals("Aprovado por Nota e Presenças", teste.CalculaNota(10.0d, 100.0d, 80, 80));
	}

	@Test
	public void testeNotas00e100() {
		assertEquals("Aprovado por Nota e Presenças", teste.CalculaNota(0.0d, 100.0d, 80, 80));
	}

	@Test
	public void testeNotas100e00() {
		assertEquals("Aprovado por Nota e Presenças", teste.CalculaNota(100.0d, 0.0d, 80, 80));
	}

	@Test
	public void testeNotas100e10() {
		assertEquals("Aprovado por Nota e Presenças", teste.CalculaNota(100.0d, 10.0d, 80, 80));
	}

	@Test
	public void testeNotas100e20() {
		assertEquals("Aprovado por Nota e Presenças", teste.CalculaNota(100.0d, 20.0d, 80, 80));
	}

	@Test
	public void testeNotas100e30() {
		assertEquals("Aprovado por Nota e Presenças", teste.CalculaNota(100.0d, 30.0d, 80, 80));
	}

	@Test
	public void testeNotas100e40() {
		assertEquals("Aprovado por Nota e Presenças", teste.CalculaNota(100.0d, 40.0d, 80, 80));
	}

	@Test
	public void testeNotas100e50() {
		assertEquals("Aprovado por Nota e Presenças", teste.CalculaNota(100.0d, 50.0d, 80, 80));
	}

	@Test
	public void testeNotas100e60() {
		assertEquals("Aprovado por Nota e Presenças", teste.CalculaNota(100.0d, 60.0d, 80, 80));
	}

	@Test
	public void testeNotas100e70() {
		assertEquals("Aprovado por Nota e Presenças", teste.CalculaNota(100.0d, 70.0d, 80, 80));
	}

	@Test
	public void testeNotas100e80() {
		assertEquals("Aprovado por Nota e Presenças", teste.CalculaNota(100.0d, 80.0d, 80, 80));
	}

	@Test
	public void testeNotas100e90() {
		assertEquals("Aprovado por Nota e Presenças", teste.CalculaNota(100.0d, 90.0d, 80, 80));
	}

}
