package br.com.crudelis.model;

public class Rendimento extends Aluno {

	Double notaN1;
	Double notaN2;
	int presencas;
	String status;

	public Double getNotaN1() {
		return notaN1;
	}

	public void setNotaN1(Double notaN1) {
		this.notaN1 = notaN1;
	}

	public Double getNotaN2() {
		return notaN2;
	}

	public void setNotaN2(Double notaN2) {
		this.notaN2 = notaN2;
	}

	public int getPresencas() {
		return presencas;
	}

	public void setPresencas(int presencas) {
		this.presencas = presencas;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
