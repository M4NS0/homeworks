import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {

  data: Date = new Date();

  horaFormatada: string = '';
  minutosFormatados: string = '';
  dataFormatada: string = '';
  mensagem: string = '';
  doisPontos: string = '';
  

  constructor() {
    this.dataFormatada = this.data.getDate().toString() + '/' 
                      + (this.data.getMonth() + 1).toString() + '/' 
                      + this.data.getFullYear().toString();

    setInterval(() => {
      this.data = new Date
      this.horaFormatada = this.getFormatado(this.data.getHours().toString())                    
      this.minutosFormatados = this.getFormatado(this.getFormatado(this.data.getMinutes().toString()))
      
      if ((this.data.getHours() >= 5) && (this.data.getHours() < 12)) {
        this.mensagem = "Bom Dia!"
      } 
      if ((this.data.getHours() >= 12) && (this.data.getHours() < 18)) {
        this.mensagem = "Boa Tarde!"
      } 
      if ((this.data.getHours() >= 18)) {
        this.mensagem = "Boa Noite!"
      } 
      this.doisPontos = ":";
    }, 1000);

    setInterval(() => {
      this.doisPontos = " "
    },100);

  }
  
  getFormatado(numStr: string) {
    if (numStr.length === 1)
      return '0' + numStr;
    else
      return numStr;
  }

}
// relogio e data no meio da tela
// estilizar relógio e data 
// funcionar em qualquer resolução
// melhorar a lógica desse TS
// a cada segundo os dois pontos fiquem piscando tirar os segundos.