import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-alarme',
  templateUrl: './alarme.component.html',
  styleUrls: ['./alarme.component.scss']
})
export class AlarmeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
