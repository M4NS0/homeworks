import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {


  
  constructor() {
 
}
}
// relogio e data no meio da tela
// estilizar relógio e data 
// funcionar em qualquer resolução
// melhorar a lógica desse TS
// a cada segundo os dois pontos fiquem piscando tirar os segundos.