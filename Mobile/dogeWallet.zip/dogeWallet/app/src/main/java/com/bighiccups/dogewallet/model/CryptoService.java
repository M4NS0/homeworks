package com.bighiccups.dogewallet.model;

public class CryptoService {
}
