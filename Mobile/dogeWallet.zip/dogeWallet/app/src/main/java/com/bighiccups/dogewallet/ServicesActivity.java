package com.bighiccups.dogewallet;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.bighiccups.dogewallet.model.Coin;
import com.bighiccups.dogewallet.model.ConversionService;
import com.bighiccups.dogewallet.model.CryptoService;



public class ServicesActivity extends AppCompatActivity {
    Coin  coin;
    Double quotation;
    Double cryptoPrice;
    String exchange;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        coin = new Coin();
        CallHttpServices();
        IntentToSecondActivity(coin);

    }

    private void IntentToSecondActivity(Coin coin) {

    }

    private void CallHttpServices() {
        ConversionService conversionService = new ConversionService();
        conversionService.execute();

//        CryptoService cryptoService = new CryptoService();
//        cryptoService.execute();

        ConstructObject();
    }

    private void ConstructObject() {
        coin.setCryptoPrice(cryptoPrice);
        coin.setExchange(exchange);
        coin.setUsdPrice(quotation);
    }


    public void setQuotation(Double quotation) {
        this.quotation = quotation;
    }

    public void setCryptoPrice(Double cryptoPrice) {
        this.cryptoPrice = cryptoPrice;
    }
}
