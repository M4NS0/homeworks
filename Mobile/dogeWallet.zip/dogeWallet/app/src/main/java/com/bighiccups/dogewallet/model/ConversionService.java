package com.bighiccups.dogewallet.model;

import android.content.Intent;
import android.os.AsyncTask;

import com.bighiccups.dogewallet.ServicesActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class ConversionService extends AsyncTask<String, String, Double> {
    @Override
    protected Double doInBackground(String... strings) {
        HttpURLConnection connection = null;
        BufferedReader buffer = null;


        try {
            URL url = new URL("https://economia.awesomeapi.com.br/last/USD-BRL");
            connection = (HttpURLConnection)url.openConnection();
            connection.setConnectTimeout(5000);
            connection.connect();
            InputStream inputStream = connection.getInputStream();
            buffer = new BufferedReader(new InputStreamReader(inputStream));
            StringBuffer stringBuffer = new StringBuffer();
            String linha = "";
            while ((linha = buffer.readLine())!= null) {
                stringBuffer.append(linha);
            }


            String cotacaoJson = stringBuffer.toString();
            JSONObject jsonObj = new JSONObject(cotacaoJson);

            return jsonObj.getJSONObject("USDBRL").getDouble("ask");

        } catch (IOException | JSONException e){
            e.printStackTrace();

        } finally {
            try {
                buffer.close();
                connection.disconnect();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    @Override
    protected void onPostExecute(Double valor) {
        super.onPostExecute(valor);
        ServicesActivity service = new ServicesActivity();
        service.setQuotation(valor);
    }
}