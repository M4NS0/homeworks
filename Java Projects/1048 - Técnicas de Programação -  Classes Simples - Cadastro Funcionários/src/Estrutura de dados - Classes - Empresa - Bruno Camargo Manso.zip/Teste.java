import java.util.Scanner;

public class Teste {
	static Scanner leia = new Scanner(System.in);
	public static int Escolha() {
		System.out.println("---------Cadastro---------"
				+ "\n1. Adicionar"
				+ "\n2. Imprimir"
				+ "\n3. Sair\n");
		int n = leia.nextInt();
		return n;
	}
	public static void main(String[] args) {
		Empresa e1 = new Empresa();
		int n = 0;
		do {
			n = Escolha();
			switch (n) {
			case 1: 
				System.out.println("Insira o nome:");
				e1.setNome(leia.next());
				
				System.out.println("Insira o Endereço de " + e1.getNome() + ":" );
				e1.setEnd(leia.next());
				
				System.out.println("Insira o cep de " + e1.getNome() + ":");
				e1.setCep(leia.next());
				
				System.out.println("Insira o telefone de " + e1.getNome() + ":");
				e1.setFone(leia.next());
				break;
			case 2:
				System.out.println(e1.toString());
				break;
				
			}

		} while (n != 3);
		
		
		
		
		
		
		
		
		
		
	}
	

}
