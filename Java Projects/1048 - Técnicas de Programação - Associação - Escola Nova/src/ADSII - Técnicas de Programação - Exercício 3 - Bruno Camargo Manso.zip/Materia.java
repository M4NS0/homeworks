
public class Materia {
	private String nomeMateria;
	
	public Materia (String nome) {
		this.nomeMateria = nome;
	}

	public String getNomeMateria() {
		return nomeMateria;
	}

	public void setNomeMateria(String nomeMateria) {
		this.nomeMateria = nomeMateria;
	}
	
}
